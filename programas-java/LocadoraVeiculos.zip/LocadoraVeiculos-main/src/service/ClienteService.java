package service;

public class ClienteService {
    public Cliente obterClientePorLocacao(int idLocacao) {
        // Lógica para obter o cliente com base no ID da locação
        // ...
        return cliente;
}

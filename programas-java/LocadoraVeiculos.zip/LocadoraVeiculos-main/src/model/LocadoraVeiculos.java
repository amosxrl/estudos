package model;
import java.util.List;

public class LocadoraVeiculos {
    private List<Veiculos> veiculosDisponiveis;
    private List<Clientes> clientes;
    private List<Aluguel> alugueis;
    // outros atributos relevantes
}

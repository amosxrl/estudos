package model;
public class GerenciadorCarros {
    //Arquivo feito pra teste
    public static void main(String[] args) {

        Veiculos a1 = new Veiculos("aaa0001","FIAT", "UNO", 2020, true);
    }
}
